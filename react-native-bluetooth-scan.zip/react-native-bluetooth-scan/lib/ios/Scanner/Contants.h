//
//  Contants.h
//  CPMSMobileApp
//
//  Created by Dũng Đình on 4/11/20.
//

#ifndef Contants_h
#define Contants_h


#endif /* Contants_h */
#define BLE_UUID_IOS @"E20A39F4-73F5-4BC4-A12F-17D1AD07A666"
#define BLE_UUID_ANDROID @"E20A39F4-73F5-4BC4-A12F-17D1AD07A888"
#define BLE_CHAR_UUID @"08590F7E-DB05-467E-8757-72F6FAEB13D"
